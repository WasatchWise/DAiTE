
// This file is no longer used in the DAiTE application.
// The SectionSelector component was part of the previous "System Design Analyzer".
// It can be safely removed from the project.
